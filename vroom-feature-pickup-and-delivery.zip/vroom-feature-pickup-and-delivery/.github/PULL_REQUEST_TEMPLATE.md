## Issue

Please link to an existing issue (or open one before submitting a PR).

## Tasks

 - [ ] ...
 - [ ] Update `docs/API.md` (remove if irrelevant)
 - [ ] Update `CHANGELOG.md` (remove if irrelevant)
 - [ ] review
